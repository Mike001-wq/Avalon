#ifndef __JB_H__
#define __JB_H__

make_helper(jb_i_b);
make_helper(jb_i_v);


#endif
