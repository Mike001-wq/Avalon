#ifndef __JGE_H__
#define __JGE_H__

make_helper(jge_i_b);
make_helper(jge_i_v);


#endif
