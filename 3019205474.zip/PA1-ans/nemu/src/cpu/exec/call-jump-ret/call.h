#ifndef __CALL_H__
#define __CALL_H__

make_helper(call_i_v);

make_helper(call_rm_v);


#endif
