#ifndef __JMP_H__
#define __JMP_H__

make_helper(jmp_i_b);
make_helper(jmp_rm_b);

make_helper(jmp_i_v);
make_helper(jmp_rm_v);
#endif
