#ifndef __JAE_H__
#define __JAE_H__

make_helper(jae_i_b);
make_helper(jae_i_v);


#endif
