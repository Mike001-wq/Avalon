#ifndef __JA_H__
#define __JA_H__

make_helper(ja_i_b);
make_helper(ja_i_v);


#endif
