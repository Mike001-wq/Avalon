#ifndef __RET_H__
#define __RET_H__

make_helper(ret_n_b);
make_helper(ret_i_b);

make_helper(ret_n_v);
make_helper(ret_i_v);

#endif
