#ifndef __NEG_H__
#define __NEG_H__

make_helper(neg_rm_b);

make_helper(neg_rm_v);

#endif
