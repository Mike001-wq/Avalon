#ifndef __CMP_H__
#define __CMP_H__

make_helper(cmp_i2a_b);
make_helper(cmp_i2rm_b);
make_helper(cmp_r2rm_b);
make_helper(cmp_rm2r_b);

make_helper(cmp_i2a_v);
make_helper(cmp_i2rm_v);
make_helper(cmp_si2rm_v);
make_helper(cmp_r2rm_v);
make_helper(cmp_rm2r_v);

#endif
